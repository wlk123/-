package Sql_con;
import java.sql.*;

public class Sql_Connection {
    Statement my_statement;
    public Object My_Connection() {
        Connection conn;
        try {

            Class.forName("com.mysql.jdbc.Driver"); // 驱动程序名
            String url = "jdbc:mysql://localhost:3306/hms_test?useUnicode=true&characterEncoding=UTF-8&useJDBCCompliantTimezoneShift=true&allowPublicKeyRetrieval=true&useLegacyDatetimeCode=false&serverTimezone=UTC&useSSL=false"; //数据库名，时区没有配置好
            //我的数据库名字是hms_test
            String username = "root";  //数据库用户名
            String password = "123456";  //数据库用户密码
            conn = DriverManager.getConnection(url, username, password);  //连接状态
            my_statement = conn.createStatement();
            if (conn != null)
                return "数据库链接成功";
            else
                return "数据库链接失败";
        } catch (Exception e) {

            return e.toString();
        }
    }
     public Statement My_Statement(){
            Sql_Connection conn1 = new Sql_Connection();
            conn1.My_Connection();
            return my_statement;

        }


    }


